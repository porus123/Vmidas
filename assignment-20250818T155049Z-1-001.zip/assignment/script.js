
  function toggleMenu() {
    const nav = document.getElementById("navLinks");
    const search = document.querySelector(".search");
    nav.classList.toggle("active");
    search.classList.toggle("active");
  }


  const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');

hamburger.addEventListener('click', () => {
  hamburger.classList.toggle('active');
  mobileMenu.classList.toggle('show');
});