
  function toggleMenu() {
    const nav = document.getElementById("navLinks");
    const search = document.querySelector(".search");
    nav.classList.toggle("active");
    search.classList.toggle("active");
  }

