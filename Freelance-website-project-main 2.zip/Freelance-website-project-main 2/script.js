document.addEventListener('DOMContentLoaded', () => {
  const hamburger = document.querySelector('.hamburger');
  const navMenu = document.querySelector('.nav-menu'); // Assuming you use .nav-menu for the links

  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active'); // Toggle active class on hamburger
    navMenu.classList.toggle('active');   // Toggle active class on navigation menu
  });
});