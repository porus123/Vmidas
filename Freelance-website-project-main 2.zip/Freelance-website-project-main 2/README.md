# Freelance-website-project
 
 1. Hosted images on https://cloudinary.com/home
 

 # TO-DO for rest of the pages
 1. Implement animations and hover effect on About, Services & Contact Page